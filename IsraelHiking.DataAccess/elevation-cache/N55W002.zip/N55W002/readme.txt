www.opendem.info
The dataset has just been subsettet and transformed to .hgt files with gdal_tanslate, no further work has been done.
Please cite this dataset as shown below.


The Digital Elevation Model over Europe from the GMES RDA project (EU-DEM) is a Digital Surface Model (DSM) representing the first surface as illuminated by the sensors.
Version 1.1
EU-DEM  in ETRS89 geographic (EPSG: 4258)
http://www.eea.europa.eu/data-and-maps/data/eu-dem

The following credit must be displayed when using these data:
"Produced using Copernicus data and information funded by the European Union - EU-DEM layers." 

Access and use of the data is made on the conditions that: 
1. When distributing or communicating Copernicus data and information to the public, users shall inform the public of the source of that data and information. 
2. Users shall make sure not to convey the impression to the public that the user's activities are officially endorsed by the Union. 
3. Where that data or information has been adapted or modified, the user shall clearly state this.